from endstone_item_banned.item_banned import ItemBanned

__all__ = ["ItemBanned"]