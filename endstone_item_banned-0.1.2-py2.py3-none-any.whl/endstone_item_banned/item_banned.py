from endstone.plugin import Plugin

class ItemBanned(Plugin):
    api_version = "0.5"

    BANNED_ITEMS = [
        "minecraft:bundle",
        "minecraft:white_bundle",
        "minecraft:light_gray_bundle",
        "minecraft:black_bundle",
        "minecraft:brown_bundle",
        "minecraft:red_bundle",
        "minecraft:orange_bundle",
        "minecraft:yellow_bundle",
        "minecraft:lime_bundle",
        "minecraft:green_bundle",
        "minecraft:magenta_bundle",
        "minecraft:light_blue_bundle",
        "minecraft:pink_bundle",
        "minecraft:gray_bundle",
        "minecraft:silver_bundle",
        "minecraft:cyan_bundle",
        "minecraft:purple_bundle",
        "minecraft:blue_bundle",
        "minecraft:redstone",
    ]

    def on_enable(self):
        self.logger.info("BannedItem включён!")
        self.server.scheduler.run_task(
            self,
            self.check_all_players,
            delay=0,
            period=20
        )

    def check_all_players(self) -> None:
        """Проверяет всех игроков"""
        for player in self.server.online_players:
            inventory = player.inventory
            if inventory is None:
                continue

            # Проверяем все слоты
            for slot in range(inventory.size):
                item = inventory.get_item(slot)
                if item is None:
                    continue

                # item.type или item.name в зависимости от версии
                item_id = getattr(item, 'type', getattr(item, 'name', str(item)))
                if item_id in self.BANNED_ITEMS:
                    inventory.set_item(slot, None)

                    player.send_message(f"§c[Защита] Удалён: {item_id}")
                    self.logger.info(f"Удалён {item_id} у {player.name}")