from pyexpat.errors import messages
from typing import List

from endstone.plugin import Plugin
from endstone.event import event_handler, PlayerChatEvent
from endstone.level import Location
from endstone import Player
import math

class Chatty(Plugin):
    api_version = "0.6"
    authors = ["Kupujljl-samu", "Kopatel"]
    prefix = "Chatty"

    commands = {}
    log_top = "╔" + "═"*28 + "╗"
    log_bottom = "╚" + "═"*28 + "╝"
    end_violators = set()
    def on_load(self):
        self.save_default_config()
        self.reload_config()

    def on_enable(self):
        self.logger.info(self.log_top)
        self.logger.info(f"║__EndStone-Chatty загружен__║")
        self.logger.info(f"║__________by Kupujljl-samu__║")
        self.logger.info(self.log_bottom)
        self.register_events(self)

    def get_nearby_players(self, center_player, radius: float = 50.0):
        """Получить игроков в радиусе"""
        nearby:List[Player] = []
        center_loc = center_player.location

        for player in self.server.online_players:
            if player.name == center_player.name:
                continue  # Пропускаем самого себя

            dist = self._distance(center_loc, player.location)
            if dist <= radius:
                nearby.append(player)
        return nearby

    @staticmethod
    def _distance(loc1:Location, loc2:Location):
        """Евклидово расстояние"""
        # Проверяем один ли мир
        if loc1.dimension.name != loc2.dimension.name:
            return float('inf')

        dx = loc1.x - loc2.x
        dy = loc1.y - loc2.y
        dz = loc1.z - loc2.z

        return math.sqrt(dx*dx + dy*dy + dz*dz)

    @event_handler
    def message(self, event: PlayerChatEvent):
        text = event.message
        player = event.player
        event.is_cancelled = True
        nearby = self.get_nearby_players(player, radius=50.0)

        if text.startswith("!"):
            message = f"""tellraw @a {{"rawtext":[{{"text":"§7[§c{player.name}§7]: §f§l{text[1:]}"}}]}}"""
            print(f"{player.name} сказал(-а) '{text[1:]}' в глобальный чат")
            self.server.dispatch_command(sender=self.server.command_sender,command_line=message)
        else:
            if len(nearby) < 1:
                message = f"""tellraw {player.name} {{"rawtext":[{{"text":"§7[§fChatty§7]: §7§lКажется вас никто не услышал..."}}]}}"""
                self.server.dispatch_command(sender=self.server.command_sender,command_line=message)
            else:
                print(f"{player.name} сказал(-а) '{text}'")
                message = f"""tellraw {player.name} {{"rawtext":[{{"text":"§7[§f{player.name}§7]: §7§l{text}"}}]}}"""
                self.server.dispatch_command(sender=self.server.command_sender,command_line=message)
                for pl in nearby:
                    message = f"""tellraw {pl.name} {{"rawtext":[{{"text":"§7[§f{player.name}§7]: §7§l{text}"}}]}}"""
                    self.server.dispatch_command(sender=self.server.command_sender,command_line=message)