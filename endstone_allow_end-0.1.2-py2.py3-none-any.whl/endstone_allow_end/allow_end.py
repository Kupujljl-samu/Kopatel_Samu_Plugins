from endstone.command import Command, CommandSender
from endstone.plugin import Plugin
from endstone.event import event_handler, PlayerDimensionChangeEvent
from endstone.level import Dimension, Location


class AllowEnd(Plugin):
    api_version = "0.6"
    authors = ["Kupujljl-samu", "Kopatel"]
    prefix = "Allow End"

    commands = {
        "allow_end": {
            "description": "Проверить статус Энда",
            "usages": ["/allow_end "],
            "permissions": ["close_end.users.allow_end"],
        },
        "allow_end_switch": {
            "description": "Включает или отключает Энд",
            "usages": ["/allow_end_switch [status: bool]"],
        }
    }
    permissions = {
        "close_end.users.allow_end": {
            "description": "Разрешает использовать команду статуса /allow_end всем игрокам",
            "default": True,
        }
    }

    log_top = "╔" + "═"*33 + "╗"
    log_bottom = "╚" + "═"*33 + "╝"
    end_violators = set()
    def on_load(self):
        self.save_default_config()
        self.reload_config()

    def on_enable(self):
        x=13
        if self.config.get('end-enabled', False):x=" "*(x+1)
        else: x=" "*x
        self.logger.info(self.log_top)
        self.logger.info(f"║   Управление эндом загружено!   ║")
        self.logger.info(f"║   End-Status: {self.config.get('end-enabled')}{x}║")
        self.logger.info(self.log_bottom)
        self.register_events(self)

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        command_name = command.name
        if command_name == "allow_end":
            if not self.config.get('end-enabled', False):message = f"[Allow End] На данный момент Энд закрыт!"
            else: message = f"[Allow End] На данный момент Энд открыт!"
            sender.send_message(message)
        elif command_name == "allow_end_switch":
            if len(args) == 0:
                if self.config.get('end-enabled', False):
                    self.config['end-enabled'] = False
                    message = "[Allow End] Энд отключён!"
                else:
                    self.config['end-enabled'] = True
                    message = "[Allow End] Энд включён!"
                sender.send_message(message)
            else:
                if args[0].lower() == "true":
                    self.config['end-enabled'] = True
                    message = "[Allow End] Энд включён!"
                else:
                    self.config['end-enabled'] = False
                    message = "[Allow End] Энд отключён!"
                sender.send_message(message)
            self.save_config()
        return True


    # def delete_end_pearl(self):
    #     if self.config.get('end-enabled', False):
    #         return
    #     for player in self.server.online_players:
    #         inventory = player.inventory
    #         if inventory is None:
    #             continue
    #
    #         for slot in range(inventory.size):
    #             item = inventory.get_item(slot)
    #             if item is None:
    #                 continue
    #
    #             item_id = getattr(item, 'type', getattr(item, 'name', str(item)))
    #             if item_id == "minecraft:ender_eye":
    #                 inventory.set_item(slot, None)
    #                 player.send_message(f"§cf[Allow End] На данный момент Энд закрыт!")
    #                 self.logger.info(f"Удалён {item_id} у {player.name}")

    @event_handler
    def player_dimension_change_event(self, event: PlayerDimensionChangeEvent):
        self.logger.info(f"Переход в {event.to_dimension.name} игроком {event.player.name}")
        if self.config.get("end-enabled", False):
            return
        if event.to_dimension.type == Dimension.THE_END:
            overworld = self.server.level.get_dimension(Dimension.OVERWORLD.name)
            location = Location(overworld, 0.5, 0.5, 400.0)
            event.player.teleport(location)
            event.player.send_message("[Allow End] На данный момент переход в энд запрещен!")
            self.logger.warning(f"Игрок {event.player.name} попытался зайти в Энд!")
