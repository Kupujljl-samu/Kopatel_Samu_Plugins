from endstone_allow_end.allow_end import AllowEnd

__all__ = ["AllowEnd"]